=========
Changelog
=========

All notable changes to this project will be documented in this file.

The format is based on `Keep a Changelog`_
and this project adheres to `Semantic Versioning`_

.. _`Semantic Versioning`: https://semver.org/spec/v2.0.0.html

.. _`Keep a Changelog`: https://keepachangelog.com/en/1.0.0/

[Unreleased]
------------
Nothing yet.

[1.0.0] - 2019-09-20
--------------------
Added
~~~~~
- Using UDL (user define language) 2.1.
- Improved handling for sections underlining. 
- Changelog (this file) added.


[0.1.0] - 2012-09-26
--------------------
Added
~~~~~
- Basic markup of reStructuredText.

*end of file*